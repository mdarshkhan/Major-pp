from django.db import models
from django.utils.timezone import now

class Prediction(models.Model):
    user_input = models.TextField()
    predicted_label = models.CharField(max_length=50)
    timestamp = models.DateTimeField(default=now)

    def __str__(self):
        return f'{self.predicted_label} ({self.timestamp})'
